## OCTOPUS 1.3.0.3 - Release date 09/17/2019
First version released using the name OCTOPUS, formerly know as Platform Trial Simulator. 

Thank you to everyone that voted in the naming survey to arrive and the final name of 
OCTOPUS - Optimize Clinical Trials on Platforms Using Simulation.

## Version 1.3.0.2
Last version using the name Platform Trial Simulator.

## Version 1.2.1.1 Release Date 04/17/2019

## Major Features

Added use of package website build with pkgdown.   

Here is some more stuff.   

# Version 1.2.1.0
Original release

