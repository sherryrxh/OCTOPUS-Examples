rm out/*.*
rm log/*.*
rm ISAOut1/*.*
rm ISAOut2/*.*
rm ISAOut3/*.*
rm ISAOut4/*.*
